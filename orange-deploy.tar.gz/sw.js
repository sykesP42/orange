const CACHE_VERSION = '3'
const STATIC_CACHE = `orange-static-v${CACHE_VERSION}`
const DYNAMIC_CACHE = `orange-dynamic-v${CACHE_VERSION}`
const API_CACHE = `orange-api-v${CACHE_VERSION}`
const IMAGE_CACHE = `orange-image-v${CACHE_VERSION}`

const MAX_DYNAMIC_SIZE = 50
const MAX_API_ENTRIES = 30
const MAX_IMAGE_SIZE = 40

const OFFLINE_URL = '/offline.html'

const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/offline.html',
  '/manifest.json',
]

const API_PATTERN = /^\/api\//
const UPLOADS_PATTERN = /^\/uploads\//
const STATIC_EXTENSIONS = /\.(js|css|woff2?|ttf|eot|svg|png|jpg|jpeg|gif|webp|ico)$/i

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll(PRECACHE_URLS).catch((err) => {
        console.log('[SW] Precache failed (some URLs may not exist yet):', err)
        return Promise.resolve()
      })
    })
  )
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      caches.keys().then((cacheNames) =>
        Promise.all(
          cacheNames
            .filter((name) => !name.includes(`v${CACHE_VERSION}`))
            .map((name) => caches.delete(name))
        )
      ),
      self.clients.claim(),
    ])
  )
})

self.addEventListener('fetch', (event) => {
  const { request } = event
  const url = new URL(request.url)

  if (request.method !== 'GET') return

  if (url.pathname === OFFLINE_URL) {
    return event.respondWith(caches.match(OFFLINE_URL) || fetch(OFFLINE_URL))
  }

  if (API_PATTERN.test(url.pathname)) {
    return handleAPIRequest(event, request)
  }

  if (UPLOADS_PATTERN.test(url.pathname)) {
    return handleImageRequest(event, request)
  }

  if (STATIC_EXTENSIONS.test(url.pathname)) {
    return handleStaticAsset(event, request)
  }

  return handleNavigationRequest(event, request)
})

async function handleAPIRequest(event, request) {
  const url = new URL(request.url)

  const networkPromise = fetch(request)
    .then(async (response) => {
      if (response.ok && response.status !== 304) {
        const clone = response.clone()
        try {
          const cache = await caches.open(API_CACHE)
          await cache.put(request, clone)
          await limitCacheSize(API_CACHE, MAX_API_ENTRIES)
        } catch (e) {}
      }
      return response
    })
    .catch(() => null)

  const cachedResponse = await caches.match(request)

  event.respondWith(
    networkPromise.then(async (networkRes) => {
      if (networkRes) return networkRes
      if (cachedResponse) {
        return new Response(JSON.stringify({
          code: -1,
          msg: '当前处于离线模式，显示的是缓存数据',
          data: await cachedResponse.clone().json().catch(() => null),
          offline: true,
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json', 'X-Offline-Cache': 'true' },
        })
      }
      return createOfflineJSONResponse(url.pathname)
    }).catch(() => cachedResponse || createOfflineJSONResponse(url.pathname))
  )
}

function createOfflineJSONResponse(pathname) {
  return new Response(JSON.stringify({
    code: -1,
    msg: '网络连接不可用，请检查网络后重试',
    data: null,
    offline: true,
  }), {
    status: 503,
    headers: { 'Content-Type': 'application/json' },
  })
}

async function handleImageRequest(event, request) {
  const cacheFirst = caches.match(request).then((cached) => {
    if (cached) return cached

    return fetch(request).then((response) => {
      if (!response || !response.ok) return response
      const clone = response.clone()
      caches.open(IMAGE_CACHE).then((cache) => {
        cache.put(request, clone)
        limitCacheSize(IMAGE_CACHE, MAX_IMAGE_SIZE)
      })
      return response
    })
  })

  event.respondWith(cacheFirst)
}

async function handleStaticAsset(event, request) {
  const cacheFirst = caches.match(request).then((cached) => {
    const fetchPromise = fetch(request).then((response) => {
      if (response && response.ok && response.type === 'basic') {
        const clone = response.clone()
        caches.open(DYNAMIC_CACHE).then((cache) => {
          cache.put(request, clone)
          limitCacheSize(DYNAMIC_CACHE, MAX_DYNAMIC_SIZE)
        })
      }
      return response
    })

    return cached || fetchPromise
  })

  event.respondWith(cacheFirst)
}

async function handleNavigationRequest(event, request) {
  event.respondWith(
    caches.match(request).then((cached) => {
      const fetchPromise = fetch(request).then((response) => {
        if (response && response.ok && response.type === 'basic') {
          const clone = response.clone()
          caches.open(DYNAMIC_CACHE).then((cache) => {
            cache.put(request, clone)
            limitCacheSize(DYNAMIC_CACHE, MAX_DYNAMIC_SIZE)
          })
        }
        return response
      }).catch(() => {
        if (request.mode === 'navigate') {
          return caches.match('/') || caches.match('/index.html')
        }
        return cached
      })

      return cached || fetchPromise
    })
  )
}

async function limitCacheSize(cacheName, maxItems) {
  const cache = await caches.open(cacheName)
  const keys = await cache.keys()

  if (keys.length > maxItems) {
    const deleteCount = keys.length - maxItems
    for (let i = 0; i < deleteCount; i++) {
      await cache.delete(keys[i])
    }
  }
}

self.addEventListener('message', (event) => {
  const { type, payload } = event.data || {}

  switch (type) {
    case 'SKIP_WAITING':
      self.skipWaiting()
      break
    case 'CLEAR_ALL_CACHES':
      clearAllCaches().then(() => {
        event.source.postMessage({ type: 'CACHES_CLEARED' })
      })
      break
    case 'GET_CACHE_INFO':
      getCacheInfo().then((info) => {
        event.source.postMessage({ type: 'CACHE_INFO', payload: info })
      })
      break
    default:
      break
  }
})

async function clearAllCaches() {
  const names = await caches.keys()
  return Promise.all(names.map((name) => caches.delete(name)))
}

async function getCacheInfo() {
  const names = await caches.keys()
  const info = {}

  for (const name of names) {
    const cache = await caches.open(name)
    const keys = await cache.keys()
    info[name] = keys.length
  }

  return info
}
